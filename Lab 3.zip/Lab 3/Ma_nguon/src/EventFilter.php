<?php
declare(strict_types=1);

function filterEvents(array $events, string $query, string $category = '',
    bool $availableOnly = false): array
{
    $result = [];
    foreach ($events as $event) {
        $matches = $query === ''
            || stripos($event['title'], $query) !== false;
        $matches = $matches
            && ($category === '' || $event['category'] === $category)
            && (!$availableOnly || $event['registered'] < $event['capacity']);
        if ($matches) {
            $result[] = $event;
        }
    }
    return $result;
}
