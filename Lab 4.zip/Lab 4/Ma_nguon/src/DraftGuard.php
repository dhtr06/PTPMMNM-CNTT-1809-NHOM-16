<?php
declare(strict_types=1);
function canComplete(array $session, int $requestedEventId, int $now, int $ttl): bool {
    $draft = $session['draft'] ?? null;
    if (!is_array($draft) || !isset($draft['data'], $draft['created_at'])) {
        return false;
    }
    if (!is_array($draft['data']) || !is_int($draft['data']['event_id'] ?? null)) {
        return false;
    }
    if (!is_int($draft['created_at']) || $ttl <= 0 || $requestedEventId <= 0) {
        return false;
    }
    if ($draft['data']['event_id'] !== $requestedEventId || $draft['created_at'] > $now) {
        return false;
    }
    return $now - $draft['created_at'] < $ttl;
}
